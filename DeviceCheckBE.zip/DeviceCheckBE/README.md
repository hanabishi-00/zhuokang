# DeviceCheckBE

#### mybatis生成所有表对象

1.  maven执行mybatis-generator:generate

#### 运行

1.  运行Application

#### 生成jar

1.  maven执行package
