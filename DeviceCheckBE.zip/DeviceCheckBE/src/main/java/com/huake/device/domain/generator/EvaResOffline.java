package com.huake.device.domain.generator;

import javax.annotation.Generated;

public class EvaResOffline {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer modelTime;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String type;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer time;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Byte unit;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String res;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getModelTime() {
        return modelTime;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setModelTime(Integer modelTime) {
        this.modelTime = modelTime;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getType() {
        return type;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setType(String type) {
        this.type = type;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getTime() {
        return time;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setTime(Integer time) {
        this.time = time;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Byte getUnit() {
        return unit;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setUnit(Byte unit) {
        this.unit = unit;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getRes() {
        return res;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setRes(String res) {
        this.res = res;
    }
}