package com.huake.device.domain;

import javax.annotation.Generated;

public class Tvf {
    private Integer t;

    private Float v;

    private Byte f;

    public Integer getT() {
        return t;
    }

    public void setT(Integer t) {
        this.t = t;
    }

    public Float getV() {
        return v;
    }

    public void setV(Float v) {
        this.v = v;
    }

    public Byte getF() {
        return f;
    }

    public void setF(Byte f) {
        this.f = f;
    }
}