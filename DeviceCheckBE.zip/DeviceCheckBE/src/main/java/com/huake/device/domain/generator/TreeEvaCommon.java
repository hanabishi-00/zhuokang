package com.huake.device.domain.generator;

import javax.annotation.Generated;

public class TreeEvaCommon {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer unitId;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String deviceId;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getUnitId() {
        return unitId;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setUnitId(Integer unitId) {
        this.unitId = unitId;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getDeviceId() {
        return deviceId;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }
}