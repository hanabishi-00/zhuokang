package com.huake.device.domain.generator;

import javax.annotation.Generated;

public class TreDeteroutputId {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer modelNum;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer output1;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer output2;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer output3;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer output4;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer output5;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer output6;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer output7;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer output8;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer output9;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer output10;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer output11;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer output12;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer output13;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer output14;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer output15;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer output16;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer output17;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer output18;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer output19;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer output20;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getModelNum() {
        return modelNum;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setModelNum(Integer modelNum) {
        this.modelNum = modelNum;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getOutput1() {
        return output1;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOutput1(Integer output1) {
        this.output1 = output1;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getOutput2() {
        return output2;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOutput2(Integer output2) {
        this.output2 = output2;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getOutput3() {
        return output3;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOutput3(Integer output3) {
        this.output3 = output3;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getOutput4() {
        return output4;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOutput4(Integer output4) {
        this.output4 = output4;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getOutput5() {
        return output5;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOutput5(Integer output5) {
        this.output5 = output5;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getOutput6() {
        return output6;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOutput6(Integer output6) {
        this.output6 = output6;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getOutput7() {
        return output7;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOutput7(Integer output7) {
        this.output7 = output7;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getOutput8() {
        return output8;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOutput8(Integer output8) {
        this.output8 = output8;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getOutput9() {
        return output9;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOutput9(Integer output9) {
        this.output9 = output9;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getOutput10() {
        return output10;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOutput10(Integer output10) {
        this.output10 = output10;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getOutput11() {
        return output11;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOutput11(Integer output11) {
        this.output11 = output11;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getOutput12() {
        return output12;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOutput12(Integer output12) {
        this.output12 = output12;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getOutput13() {
        return output13;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOutput13(Integer output13) {
        this.output13 = output13;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getOutput14() {
        return output14;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOutput14(Integer output14) {
        this.output14 = output14;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getOutput15() {
        return output15;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOutput15(Integer output15) {
        this.output15 = output15;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getOutput16() {
        return output16;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOutput16(Integer output16) {
        this.output16 = output16;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getOutput17() {
        return output17;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOutput17(Integer output17) {
        this.output17 = output17;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getOutput18() {
        return output18;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOutput18(Integer output18) {
        this.output18 = output18;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getOutput19() {
        return output19;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOutput19(Integer output19) {
        this.output19 = output19;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getOutput20() {
        return output20;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOutput20(Integer output20) {
        this.output20 = output20;
    }
}