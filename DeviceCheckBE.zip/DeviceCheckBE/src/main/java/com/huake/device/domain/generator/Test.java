package com.huake.device.domain.generator;

import javax.annotation.Generated;

public class Test {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String name;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String age;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String des;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getName() {
        return name;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setName(String name) {
        this.name = name;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getAge() {
        return age;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setAge(String age) {
        this.age = age;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getDes() {
        return des;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setDes(String des) {
        this.des = des;
    }
}