package com.huake.device.dao.generator;

import java.sql.JDBCType;
import javax.annotation.Generated;
import org.mybatis.dynamic.sql.SqlColumn;
import org.mybatis.dynamic.sql.SqlTable;

public final class EvaResTur20200001LeafOfflineDynamicSqlSupport {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final EvaResTur20200001LeafOffline evaResTur20200001LeafOffline = new EvaResTur20200001LeafOffline();

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> time = evaResTur20200001LeafOffline.time;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Byte> unit = evaResTur20200001LeafOffline.unit;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v0 = evaResTur20200001LeafOffline.v0;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v1 = evaResTur20200001LeafOffline.v1;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v2 = evaResTur20200001LeafOffline.v2;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v3 = evaResTur20200001LeafOffline.v3;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v4 = evaResTur20200001LeafOffline.v4;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v5 = evaResTur20200001LeafOffline.v5;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v6 = evaResTur20200001LeafOffline.v6;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v7 = evaResTur20200001LeafOffline.v7;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v8 = evaResTur20200001LeafOffline.v8;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v9 = evaResTur20200001LeafOffline.v9;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v10 = evaResTur20200001LeafOffline.v10;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v11 = evaResTur20200001LeafOffline.v11;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v12 = evaResTur20200001LeafOffline.v12;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v13 = evaResTur20200001LeafOffline.v13;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v14 = evaResTur20200001LeafOffline.v14;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v15 = evaResTur20200001LeafOffline.v15;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v16 = evaResTur20200001LeafOffline.v16;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v17 = evaResTur20200001LeafOffline.v17;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v18 = evaResTur20200001LeafOffline.v18;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v19 = evaResTur20200001LeafOffline.v19;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v20 = evaResTur20200001LeafOffline.v20;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v21 = evaResTur20200001LeafOffline.v21;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v22 = evaResTur20200001LeafOffline.v22;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v23 = evaResTur20200001LeafOffline.v23;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v24 = evaResTur20200001LeafOffline.v24;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v25 = evaResTur20200001LeafOffline.v25;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v26 = evaResTur20200001LeafOffline.v26;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v27 = evaResTur20200001LeafOffline.v27;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v28 = evaResTur20200001LeafOffline.v28;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v29 = evaResTur20200001LeafOffline.v29;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v30 = evaResTur20200001LeafOffline.v30;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v31 = evaResTur20200001LeafOffline.v31;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v32 = evaResTur20200001LeafOffline.v32;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v33 = evaResTur20200001LeafOffline.v33;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v34 = evaResTur20200001LeafOffline.v34;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v35 = evaResTur20200001LeafOffline.v35;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v36 = evaResTur20200001LeafOffline.v36;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v37 = evaResTur20200001LeafOffline.v37;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v38 = evaResTur20200001LeafOffline.v38;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v39 = evaResTur20200001LeafOffline.v39;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v40 = evaResTur20200001LeafOffline.v40;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v41 = evaResTur20200001LeafOffline.v41;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v42 = evaResTur20200001LeafOffline.v42;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v43 = evaResTur20200001LeafOffline.v43;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v44 = evaResTur20200001LeafOffline.v44;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v45 = evaResTur20200001LeafOffline.v45;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v46 = evaResTur20200001LeafOffline.v46;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v47 = evaResTur20200001LeafOffline.v47;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v48 = evaResTur20200001LeafOffline.v48;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v49 = evaResTur20200001LeafOffline.v49;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v50 = evaResTur20200001LeafOffline.v50;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v51 = evaResTur20200001LeafOffline.v51;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v52 = evaResTur20200001LeafOffline.v52;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v53 = evaResTur20200001LeafOffline.v53;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v54 = evaResTur20200001LeafOffline.v54;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v55 = evaResTur20200001LeafOffline.v55;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v56 = evaResTur20200001LeafOffline.v56;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v57 = evaResTur20200001LeafOffline.v57;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v58 = evaResTur20200001LeafOffline.v58;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v59 = evaResTur20200001LeafOffline.v59;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v60 = evaResTur20200001LeafOffline.v60;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v61 = evaResTur20200001LeafOffline.v61;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v62 = evaResTur20200001LeafOffline.v62;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v63 = evaResTur20200001LeafOffline.v63;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v64 = evaResTur20200001LeafOffline.v64;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v65 = evaResTur20200001LeafOffline.v65;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v66 = evaResTur20200001LeafOffline.v66;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v67 = evaResTur20200001LeafOffline.v67;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v68 = evaResTur20200001LeafOffline.v68;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v69 = evaResTur20200001LeafOffline.v69;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v70 = evaResTur20200001LeafOffline.v70;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v71 = evaResTur20200001LeafOffline.v71;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v72 = evaResTur20200001LeafOffline.v72;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v73 = evaResTur20200001LeafOffline.v73;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v74 = evaResTur20200001LeafOffline.v74;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v75 = evaResTur20200001LeafOffline.v75;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v76 = evaResTur20200001LeafOffline.v76;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v77 = evaResTur20200001LeafOffline.v77;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v78 = evaResTur20200001LeafOffline.v78;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v79 = evaResTur20200001LeafOffline.v79;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v80 = evaResTur20200001LeafOffline.v80;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v81 = evaResTur20200001LeafOffline.v81;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v82 = evaResTur20200001LeafOffline.v82;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v83 = evaResTur20200001LeafOffline.v83;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v84 = evaResTur20200001LeafOffline.v84;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v85 = evaResTur20200001LeafOffline.v85;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v86 = evaResTur20200001LeafOffline.v86;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v87 = evaResTur20200001LeafOffline.v87;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v88 = evaResTur20200001LeafOffline.v88;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v89 = evaResTur20200001LeafOffline.v89;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v90 = evaResTur20200001LeafOffline.v90;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v91 = evaResTur20200001LeafOffline.v91;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v92 = evaResTur20200001LeafOffline.v92;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v93 = evaResTur20200001LeafOffline.v93;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v94 = evaResTur20200001LeafOffline.v94;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v95 = evaResTur20200001LeafOffline.v95;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v96 = evaResTur20200001LeafOffline.v96;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v97 = evaResTur20200001LeafOffline.v97;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v98 = evaResTur20200001LeafOffline.v98;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v99 = evaResTur20200001LeafOffline.v99;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v100 = evaResTur20200001LeafOffline.v100;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v101 = evaResTur20200001LeafOffline.v101;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v102 = evaResTur20200001LeafOffline.v102;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v103 = evaResTur20200001LeafOffline.v103;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v104 = evaResTur20200001LeafOffline.v104;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v105 = evaResTur20200001LeafOffline.v105;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v106 = evaResTur20200001LeafOffline.v106;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v107 = evaResTur20200001LeafOffline.v107;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Float> v108 = evaResTur20200001LeafOffline.v108;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final class EvaResTur20200001LeafOffline extends SqlTable {
        public final SqlColumn<Integer> time = column("time", JDBCType.INTEGER);

        public final SqlColumn<Byte> unit = column("unit", JDBCType.TINYINT);

        public final SqlColumn<Float> v0 = column("v0", JDBCType.REAL);

        public final SqlColumn<Float> v1 = column("v1", JDBCType.REAL);

        public final SqlColumn<Float> v2 = column("v2", JDBCType.REAL);

        public final SqlColumn<Float> v3 = column("v3", JDBCType.REAL);

        public final SqlColumn<Float> v4 = column("v4", JDBCType.REAL);

        public final SqlColumn<Float> v5 = column("v5", JDBCType.REAL);

        public final SqlColumn<Float> v6 = column("v6", JDBCType.REAL);

        public final SqlColumn<Float> v7 = column("v7", JDBCType.REAL);

        public final SqlColumn<Float> v8 = column("v8", JDBCType.REAL);

        public final SqlColumn<Float> v9 = column("v9", JDBCType.REAL);

        public final SqlColumn<Float> v10 = column("v10", JDBCType.REAL);

        public final SqlColumn<Float> v11 = column("v11", JDBCType.REAL);

        public final SqlColumn<Float> v12 = column("v12", JDBCType.REAL);

        public final SqlColumn<Float> v13 = column("v13", JDBCType.REAL);

        public final SqlColumn<Float> v14 = column("v14", JDBCType.REAL);

        public final SqlColumn<Float> v15 = column("v15", JDBCType.REAL);

        public final SqlColumn<Float> v16 = column("v16", JDBCType.REAL);

        public final SqlColumn<Float> v17 = column("v17", JDBCType.REAL);

        public final SqlColumn<Float> v18 = column("v18", JDBCType.REAL);

        public final SqlColumn<Float> v19 = column("v19", JDBCType.REAL);

        public final SqlColumn<Float> v20 = column("v20", JDBCType.REAL);

        public final SqlColumn<Float> v21 = column("v21", JDBCType.REAL);

        public final SqlColumn<Float> v22 = column("v22", JDBCType.REAL);

        public final SqlColumn<Float> v23 = column("v23", JDBCType.REAL);

        public final SqlColumn<Float> v24 = column("v24", JDBCType.REAL);

        public final SqlColumn<Float> v25 = column("v25", JDBCType.REAL);

        public final SqlColumn<Float> v26 = column("v26", JDBCType.REAL);

        public final SqlColumn<Float> v27 = column("v27", JDBCType.REAL);

        public final SqlColumn<Float> v28 = column("v28", JDBCType.REAL);

        public final SqlColumn<Float> v29 = column("v29", JDBCType.REAL);

        public final SqlColumn<Float> v30 = column("v30", JDBCType.REAL);

        public final SqlColumn<Float> v31 = column("v31", JDBCType.REAL);

        public final SqlColumn<Float> v32 = column("v32", JDBCType.REAL);

        public final SqlColumn<Float> v33 = column("v33", JDBCType.REAL);

        public final SqlColumn<Float> v34 = column("v34", JDBCType.REAL);

        public final SqlColumn<Float> v35 = column("v35", JDBCType.REAL);

        public final SqlColumn<Float> v36 = column("v36", JDBCType.REAL);

        public final SqlColumn<Float> v37 = column("v37", JDBCType.REAL);

        public final SqlColumn<Float> v38 = column("v38", JDBCType.REAL);

        public final SqlColumn<Float> v39 = column("v39", JDBCType.REAL);

        public final SqlColumn<Float> v40 = column("v40", JDBCType.REAL);

        public final SqlColumn<Float> v41 = column("v41", JDBCType.REAL);

        public final SqlColumn<Float> v42 = column("v42", JDBCType.REAL);

        public final SqlColumn<Float> v43 = column("v43", JDBCType.REAL);

        public final SqlColumn<Float> v44 = column("v44", JDBCType.REAL);

        public final SqlColumn<Float> v45 = column("v45", JDBCType.REAL);

        public final SqlColumn<Float> v46 = column("v46", JDBCType.REAL);

        public final SqlColumn<Float> v47 = column("v47", JDBCType.REAL);

        public final SqlColumn<Float> v48 = column("v48", JDBCType.REAL);

        public final SqlColumn<Float> v49 = column("v49", JDBCType.REAL);

        public final SqlColumn<Float> v50 = column("v50", JDBCType.REAL);

        public final SqlColumn<Float> v51 = column("v51", JDBCType.REAL);

        public final SqlColumn<Float> v52 = column("v52", JDBCType.REAL);

        public final SqlColumn<Float> v53 = column("v53", JDBCType.REAL);

        public final SqlColumn<Float> v54 = column("v54", JDBCType.REAL);

        public final SqlColumn<Float> v55 = column("v55", JDBCType.REAL);

        public final SqlColumn<Float> v56 = column("v56", JDBCType.REAL);

        public final SqlColumn<Float> v57 = column("v57", JDBCType.REAL);

        public final SqlColumn<Float> v58 = column("v58", JDBCType.REAL);

        public final SqlColumn<Float> v59 = column("v59", JDBCType.REAL);

        public final SqlColumn<Float> v60 = column("v60", JDBCType.REAL);

        public final SqlColumn<Float> v61 = column("v61", JDBCType.REAL);

        public final SqlColumn<Float> v62 = column("v62", JDBCType.REAL);

        public final SqlColumn<Float> v63 = column("v63", JDBCType.REAL);

        public final SqlColumn<Float> v64 = column("v64", JDBCType.REAL);

        public final SqlColumn<Float> v65 = column("v65", JDBCType.REAL);

        public final SqlColumn<Float> v66 = column("v66", JDBCType.REAL);

        public final SqlColumn<Float> v67 = column("v67", JDBCType.REAL);

        public final SqlColumn<Float> v68 = column("v68", JDBCType.REAL);

        public final SqlColumn<Float> v69 = column("v69", JDBCType.REAL);

        public final SqlColumn<Float> v70 = column("v70", JDBCType.REAL);

        public final SqlColumn<Float> v71 = column("v71", JDBCType.REAL);

        public final SqlColumn<Float> v72 = column("v72", JDBCType.REAL);

        public final SqlColumn<Float> v73 = column("v73", JDBCType.REAL);

        public final SqlColumn<Float> v74 = column("v74", JDBCType.REAL);

        public final SqlColumn<Float> v75 = column("v75", JDBCType.REAL);

        public final SqlColumn<Float> v76 = column("v76", JDBCType.REAL);

        public final SqlColumn<Float> v77 = column("v77", JDBCType.REAL);

        public final SqlColumn<Float> v78 = column("v78", JDBCType.REAL);

        public final SqlColumn<Float> v79 = column("v79", JDBCType.REAL);

        public final SqlColumn<Float> v80 = column("v80", JDBCType.REAL);

        public final SqlColumn<Float> v81 = column("v81", JDBCType.REAL);

        public final SqlColumn<Float> v82 = column("v82", JDBCType.REAL);

        public final SqlColumn<Float> v83 = column("v83", JDBCType.REAL);

        public final SqlColumn<Float> v84 = column("v84", JDBCType.REAL);

        public final SqlColumn<Float> v85 = column("v85", JDBCType.REAL);

        public final SqlColumn<Float> v86 = column("v86", JDBCType.REAL);

        public final SqlColumn<Float> v87 = column("v87", JDBCType.REAL);

        public final SqlColumn<Float> v88 = column("v88", JDBCType.REAL);

        public final SqlColumn<Float> v89 = column("v89", JDBCType.REAL);

        public final SqlColumn<Float> v90 = column("v90", JDBCType.REAL);

        public final SqlColumn<Float> v91 = column("v91", JDBCType.REAL);

        public final SqlColumn<Float> v92 = column("v92", JDBCType.REAL);

        public final SqlColumn<Float> v93 = column("v93", JDBCType.REAL);

        public final SqlColumn<Float> v94 = column("v94", JDBCType.REAL);

        public final SqlColumn<Float> v95 = column("v95", JDBCType.REAL);

        public final SqlColumn<Float> v96 = column("v96", JDBCType.REAL);

        public final SqlColumn<Float> v97 = column("v97", JDBCType.REAL);

        public final SqlColumn<Float> v98 = column("v98", JDBCType.REAL);

        public final SqlColumn<Float> v99 = column("v99", JDBCType.REAL);

        public final SqlColumn<Float> v100 = column("v100", JDBCType.REAL);

        public final SqlColumn<Float> v101 = column("v101", JDBCType.REAL);

        public final SqlColumn<Float> v102 = column("v102", JDBCType.REAL);

        public final SqlColumn<Float> v103 = column("v103", JDBCType.REAL);

        public final SqlColumn<Float> v104 = column("v104", JDBCType.REAL);

        public final SqlColumn<Float> v105 = column("v105", JDBCType.REAL);

        public final SqlColumn<Float> v106 = column("v106", JDBCType.REAL);

        public final SqlColumn<Float> v107 = column("v107", JDBCType.REAL);

        public final SqlColumn<Float> v108 = column("v108", JDBCType.REAL);

        public EvaResTur20200001LeafOffline() {
            super("eva_res_tur_20200001_leaf_offline");
        }
    }
}