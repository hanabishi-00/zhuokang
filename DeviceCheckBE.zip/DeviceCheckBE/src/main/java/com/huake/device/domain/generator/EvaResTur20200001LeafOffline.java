package com.huake.device.domain.generator;

import javax.annotation.Generated;

public class EvaResTur20200001LeafOffline {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer time;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Byte unit;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v0;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v1;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v2;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v3;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v4;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v5;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v6;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v7;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v8;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v9;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v10;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v11;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v12;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v13;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v14;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v15;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v16;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v17;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v18;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v19;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v20;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v21;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v22;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v23;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v24;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v25;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v26;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v27;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v28;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v29;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v30;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v31;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v32;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v33;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v34;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v35;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v36;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v37;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v38;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v39;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v40;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v41;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v42;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v43;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v44;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v45;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v46;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v47;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v48;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v49;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v50;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v51;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v52;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v53;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v54;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v55;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v56;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v57;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v58;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v59;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v60;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v61;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v62;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v63;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v64;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v65;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v66;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v67;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v68;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v69;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v70;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v71;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v72;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v73;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v74;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v75;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v76;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v77;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v78;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v79;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v80;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v81;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v82;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v83;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v84;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v85;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v86;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v87;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v88;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v89;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v90;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v91;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v92;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v93;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v94;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v95;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v96;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v97;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v98;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v99;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v100;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v101;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v102;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v103;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v104;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v105;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v106;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v107;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v108;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getTime() {
        return time;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setTime(Integer time) {
        this.time = time;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Byte getUnit() {
        return unit;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setUnit(Byte unit) {
        this.unit = unit;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV0() {
        return v0;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV0(Float v0) {
        this.v0 = v0;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV1() {
        return v1;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV1(Float v1) {
        this.v1 = v1;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV2() {
        return v2;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV2(Float v2) {
        this.v2 = v2;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV3() {
        return v3;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV3(Float v3) {
        this.v3 = v3;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV4() {
        return v4;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV4(Float v4) {
        this.v4 = v4;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV5() {
        return v5;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV5(Float v5) {
        this.v5 = v5;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV6() {
        return v6;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV6(Float v6) {
        this.v6 = v6;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV7() {
        return v7;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV7(Float v7) {
        this.v7 = v7;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV8() {
        return v8;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV8(Float v8) {
        this.v8 = v8;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV9() {
        return v9;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV9(Float v9) {
        this.v9 = v9;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV10() {
        return v10;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV10(Float v10) {
        this.v10 = v10;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV11() {
        return v11;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV11(Float v11) {
        this.v11 = v11;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV12() {
        return v12;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV12(Float v12) {
        this.v12 = v12;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV13() {
        return v13;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV13(Float v13) {
        this.v13 = v13;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV14() {
        return v14;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV14(Float v14) {
        this.v14 = v14;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV15() {
        return v15;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV15(Float v15) {
        this.v15 = v15;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV16() {
        return v16;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV16(Float v16) {
        this.v16 = v16;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV17() {
        return v17;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV17(Float v17) {
        this.v17 = v17;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV18() {
        return v18;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV18(Float v18) {
        this.v18 = v18;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV19() {
        return v19;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV19(Float v19) {
        this.v19 = v19;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV20() {
        return v20;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV20(Float v20) {
        this.v20 = v20;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV21() {
        return v21;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV21(Float v21) {
        this.v21 = v21;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV22() {
        return v22;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV22(Float v22) {
        this.v22 = v22;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV23() {
        return v23;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV23(Float v23) {
        this.v23 = v23;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV24() {
        return v24;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV24(Float v24) {
        this.v24 = v24;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV25() {
        return v25;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV25(Float v25) {
        this.v25 = v25;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV26() {
        return v26;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV26(Float v26) {
        this.v26 = v26;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV27() {
        return v27;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV27(Float v27) {
        this.v27 = v27;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV28() {
        return v28;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV28(Float v28) {
        this.v28 = v28;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV29() {
        return v29;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV29(Float v29) {
        this.v29 = v29;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV30() {
        return v30;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV30(Float v30) {
        this.v30 = v30;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV31() {
        return v31;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV31(Float v31) {
        this.v31 = v31;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV32() {
        return v32;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV32(Float v32) {
        this.v32 = v32;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV33() {
        return v33;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV33(Float v33) {
        this.v33 = v33;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV34() {
        return v34;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV34(Float v34) {
        this.v34 = v34;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV35() {
        return v35;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV35(Float v35) {
        this.v35 = v35;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV36() {
        return v36;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV36(Float v36) {
        this.v36 = v36;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV37() {
        return v37;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV37(Float v37) {
        this.v37 = v37;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV38() {
        return v38;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV38(Float v38) {
        this.v38 = v38;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV39() {
        return v39;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV39(Float v39) {
        this.v39 = v39;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV40() {
        return v40;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV40(Float v40) {
        this.v40 = v40;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV41() {
        return v41;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV41(Float v41) {
        this.v41 = v41;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV42() {
        return v42;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV42(Float v42) {
        this.v42 = v42;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV43() {
        return v43;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV43(Float v43) {
        this.v43 = v43;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV44() {
        return v44;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV44(Float v44) {
        this.v44 = v44;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV45() {
        return v45;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV45(Float v45) {
        this.v45 = v45;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV46() {
        return v46;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV46(Float v46) {
        this.v46 = v46;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV47() {
        return v47;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV47(Float v47) {
        this.v47 = v47;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV48() {
        return v48;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV48(Float v48) {
        this.v48 = v48;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV49() {
        return v49;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV49(Float v49) {
        this.v49 = v49;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV50() {
        return v50;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV50(Float v50) {
        this.v50 = v50;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV51() {
        return v51;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV51(Float v51) {
        this.v51 = v51;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV52() {
        return v52;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV52(Float v52) {
        this.v52 = v52;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV53() {
        return v53;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV53(Float v53) {
        this.v53 = v53;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV54() {
        return v54;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV54(Float v54) {
        this.v54 = v54;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV55() {
        return v55;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV55(Float v55) {
        this.v55 = v55;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV56() {
        return v56;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV56(Float v56) {
        this.v56 = v56;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV57() {
        return v57;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV57(Float v57) {
        this.v57 = v57;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV58() {
        return v58;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV58(Float v58) {
        this.v58 = v58;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV59() {
        return v59;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV59(Float v59) {
        this.v59 = v59;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV60() {
        return v60;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV60(Float v60) {
        this.v60 = v60;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV61() {
        return v61;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV61(Float v61) {
        this.v61 = v61;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV62() {
        return v62;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV62(Float v62) {
        this.v62 = v62;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV63() {
        return v63;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV63(Float v63) {
        this.v63 = v63;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV64() {
        return v64;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV64(Float v64) {
        this.v64 = v64;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV65() {
        return v65;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV65(Float v65) {
        this.v65 = v65;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV66() {
        return v66;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV66(Float v66) {
        this.v66 = v66;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV67() {
        return v67;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV67(Float v67) {
        this.v67 = v67;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV68() {
        return v68;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV68(Float v68) {
        this.v68 = v68;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV69() {
        return v69;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV69(Float v69) {
        this.v69 = v69;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV70() {
        return v70;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV70(Float v70) {
        this.v70 = v70;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV71() {
        return v71;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV71(Float v71) {
        this.v71 = v71;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV72() {
        return v72;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV72(Float v72) {
        this.v72 = v72;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV73() {
        return v73;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV73(Float v73) {
        this.v73 = v73;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV74() {
        return v74;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV74(Float v74) {
        this.v74 = v74;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV75() {
        return v75;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV75(Float v75) {
        this.v75 = v75;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV76() {
        return v76;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV76(Float v76) {
        this.v76 = v76;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV77() {
        return v77;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV77(Float v77) {
        this.v77 = v77;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV78() {
        return v78;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV78(Float v78) {
        this.v78 = v78;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV79() {
        return v79;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV79(Float v79) {
        this.v79 = v79;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV80() {
        return v80;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV80(Float v80) {
        this.v80 = v80;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV81() {
        return v81;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV81(Float v81) {
        this.v81 = v81;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV82() {
        return v82;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV82(Float v82) {
        this.v82 = v82;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV83() {
        return v83;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV83(Float v83) {
        this.v83 = v83;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV84() {
        return v84;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV84(Float v84) {
        this.v84 = v84;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV85() {
        return v85;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV85(Float v85) {
        this.v85 = v85;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV86() {
        return v86;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV86(Float v86) {
        this.v86 = v86;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV87() {
        return v87;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV87(Float v87) {
        this.v87 = v87;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV88() {
        return v88;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV88(Float v88) {
        this.v88 = v88;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV89() {
        return v89;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV89(Float v89) {
        this.v89 = v89;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV90() {
        return v90;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV90(Float v90) {
        this.v90 = v90;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV91() {
        return v91;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV91(Float v91) {
        this.v91 = v91;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV92() {
        return v92;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV92(Float v92) {
        this.v92 = v92;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV93() {
        return v93;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV93(Float v93) {
        this.v93 = v93;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV94() {
        return v94;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV94(Float v94) {
        this.v94 = v94;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV95() {
        return v95;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV95(Float v95) {
        this.v95 = v95;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV96() {
        return v96;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV96(Float v96) {
        this.v96 = v96;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV97() {
        return v97;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV97(Float v97) {
        this.v97 = v97;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV98() {
        return v98;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV98(Float v98) {
        this.v98 = v98;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV99() {
        return v99;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV99(Float v99) {
        this.v99 = v99;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV100() {
        return v100;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV100(Float v100) {
        this.v100 = v100;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV101() {
        return v101;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV101(Float v101) {
        this.v101 = v101;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV102() {
        return v102;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV102(Float v102) {
        this.v102 = v102;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV103() {
        return v103;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV103(Float v103) {
        this.v103 = v103;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV104() {
        return v104;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV104(Float v104) {
        this.v104 = v104;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV105() {
        return v105;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV105(Float v105) {
        this.v105 = v105;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV106() {
        return v106;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV106(Float v106) {
        this.v106 = v106;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV107() {
        return v107;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV107(Float v107) {
        this.v107 = v107;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV108() {
        return v108;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV108(Float v108) {
        this.v108 = v108;
    }
}