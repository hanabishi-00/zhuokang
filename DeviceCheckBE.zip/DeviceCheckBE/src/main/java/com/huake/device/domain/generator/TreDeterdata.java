package com.huake.device.domain.generator;

import javax.annotation.Generated;

public class TreDeterdata {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer runtime;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer time;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float deter;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String idVersion;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getRuntime() {
        return runtime;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setRuntime(Integer runtime) {
        this.runtime = runtime;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getTime() {
        return time;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setTime(Integer time) {
        this.time = time;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getDeter() {
        return deter;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setDeter(Float deter) {
        this.deter = deter;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getIdVersion() {
        return idVersion;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setIdVersion(String idVersion) {
        this.idVersion = idVersion;
    }
}