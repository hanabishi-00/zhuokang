package com.huake.device.domain.generator;

import javax.annotation.Generated;

public class EvaTag {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String key;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String type;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String name;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getKey() {
        return key;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setKey(String key) {
        this.key = key;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getType() {
        return type;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setType(String type) {
        this.type = type;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getName() {
        return name;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setName(String name) {
        this.name = name;
    }
}