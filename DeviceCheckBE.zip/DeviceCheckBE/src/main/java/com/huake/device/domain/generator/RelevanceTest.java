package com.huake.device.domain.generator;

import javax.annotation.Generated;

public class RelevanceTest {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String seq;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer id;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer relId;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float relevance;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getSeq() {
        return seq;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setSeq(String seq) {
        this.seq = seq;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getId() {
        return id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setId(Integer id) {
        this.id = id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getRelId() {
        return relId;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setRelId(Integer relId) {
        this.relId = relId;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getRelevance() {
        return relevance;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setRelevance(Float relevance) {
        this.relevance = relevance;
    }
}