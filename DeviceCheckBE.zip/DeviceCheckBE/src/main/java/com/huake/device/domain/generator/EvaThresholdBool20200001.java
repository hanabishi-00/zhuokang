package com.huake.device.domain.generator;

import javax.annotation.Generated;

public class EvaThresholdBool20200001 {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer id;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String threshold;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getId() {
        return id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setId(Integer id) {
        this.id = id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getThreshold() {
        return threshold;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setThreshold(String threshold) {
        this.threshold = threshold;
    }
}