package com.huake.device.domain.generator;

import javax.annotation.Generated;

public class TreDeterpre101001 {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer pretime;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float predeter;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Byte warnsig;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getPretime() {
        return pretime;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setPretime(Integer pretime) {
        this.pretime = pretime;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getPredeter() {
        return predeter;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setPredeter(Float predeter) {
        this.predeter = predeter;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Byte getWarnsig() {
        return warnsig;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setWarnsig(Byte warnsig) {
        this.warnsig = warnsig;
    }
}