package com.huake.device.domain.generator;

import javax.annotation.Generated;

public class MadiagHisProcess {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer id;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer unitId;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String equipPro;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String time;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getId() {
        return id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setId(Integer id) {
        this.id = id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getUnitId() {
        return unitId;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setUnitId(Integer unitId) {
        this.unitId = unitId;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getEquipPro() {
        return equipPro;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setEquipPro(String equipPro) {
        this.equipPro = equipPro;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getTime() {
        return time;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setTime(String time) {
        this.time = time;
    }
}