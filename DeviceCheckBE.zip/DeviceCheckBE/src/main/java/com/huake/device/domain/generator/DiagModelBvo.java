package com.huake.device.domain.generator;

import javax.annotation.Generated;

public class DiagModelBvo {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer id;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String name;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer pid;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String fatherName;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String gatetype;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String points;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String method;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String threshold;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getId() {
        return id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setId(Integer id) {
        this.id = id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getName() {
        return name;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setName(String name) {
        this.name = name;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getPid() {
        return pid;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setPid(Integer pid) {
        this.pid = pid;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getFatherName() {
        return fatherName;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getGatetype() {
        return gatetype;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setGatetype(String gatetype) {
        this.gatetype = gatetype;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getPoints() {
        return points;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setPoints(String points) {
        this.points = points;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getMethod() {
        return method;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setMethod(String method) {
        this.method = method;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getThreshold() {
        return threshold;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setThreshold(String threshold) {
        this.threshold = threshold;
    }
}