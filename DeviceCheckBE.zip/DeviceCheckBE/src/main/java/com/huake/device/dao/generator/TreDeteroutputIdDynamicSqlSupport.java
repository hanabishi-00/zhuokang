package com.huake.device.dao.generator;

import java.sql.JDBCType;
import javax.annotation.Generated;
import org.mybatis.dynamic.sql.SqlColumn;
import org.mybatis.dynamic.sql.SqlTable;

public final class TreDeteroutputIdDynamicSqlSupport {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final TreDeteroutputId treDeteroutputId = new TreDeteroutputId();

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> modelNum = treDeteroutputId.modelNum;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> output1 = treDeteroutputId.output1;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> output2 = treDeteroutputId.output2;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> output3 = treDeteroutputId.output3;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> output4 = treDeteroutputId.output4;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> output5 = treDeteroutputId.output5;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> output6 = treDeteroutputId.output6;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> output7 = treDeteroutputId.output7;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> output8 = treDeteroutputId.output8;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> output9 = treDeteroutputId.output9;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> output10 = treDeteroutputId.output10;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> output11 = treDeteroutputId.output11;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> output12 = treDeteroutputId.output12;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> output13 = treDeteroutputId.output13;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> output14 = treDeteroutputId.output14;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> output15 = treDeteroutputId.output15;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> output16 = treDeteroutputId.output16;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> output17 = treDeteroutputId.output17;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> output18 = treDeteroutputId.output18;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> output19 = treDeteroutputId.output19;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> output20 = treDeteroutputId.output20;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final class TreDeteroutputId extends SqlTable {
        public final SqlColumn<Integer> modelNum = column("model_num", JDBCType.INTEGER);

        public final SqlColumn<Integer> output1 = column("output1", JDBCType.INTEGER);

        public final SqlColumn<Integer> output2 = column("output2", JDBCType.INTEGER);

        public final SqlColumn<Integer> output3 = column("output3", JDBCType.INTEGER);

        public final SqlColumn<Integer> output4 = column("output4", JDBCType.INTEGER);

        public final SqlColumn<Integer> output5 = column("output5", JDBCType.INTEGER);

        public final SqlColumn<Integer> output6 = column("output6", JDBCType.INTEGER);

        public final SqlColumn<Integer> output7 = column("output7", JDBCType.INTEGER);

        public final SqlColumn<Integer> output8 = column("output8", JDBCType.INTEGER);

        public final SqlColumn<Integer> output9 = column("output9", JDBCType.INTEGER);

        public final SqlColumn<Integer> output10 = column("output10", JDBCType.INTEGER);

        public final SqlColumn<Integer> output11 = column("output11", JDBCType.INTEGER);

        public final SqlColumn<Integer> output12 = column("output12", JDBCType.INTEGER);

        public final SqlColumn<Integer> output13 = column("output13", JDBCType.INTEGER);

        public final SqlColumn<Integer> output14 = column("output14", JDBCType.INTEGER);

        public final SqlColumn<Integer> output15 = column("output15", JDBCType.INTEGER);

        public final SqlColumn<Integer> output16 = column("output16", JDBCType.INTEGER);

        public final SqlColumn<Integer> output17 = column("output17", JDBCType.INTEGER);

        public final SqlColumn<Integer> output18 = column("output18", JDBCType.INTEGER);

        public final SqlColumn<Integer> output19 = column("output19", JDBCType.INTEGER);

        public final SqlColumn<Integer> output20 = column("output20", JDBCType.INTEGER);

        public TreDeteroutputId() {
            super("tre_deteroutput_id");
        }
    }
}