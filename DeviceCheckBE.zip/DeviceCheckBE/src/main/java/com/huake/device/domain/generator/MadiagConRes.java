package com.huake.device.domain.generator;

import javax.annotation.Generated;

public class MadiagConRes {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer id;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String openCon;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String operPro;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String conproInt;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getId() {
        return id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setId(Integer id) {
        this.id = id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getOpenCon() {
        return openCon;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOpenCon(String openCon) {
        this.openCon = openCon;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getOperPro() {
        return operPro;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOperPro(String operPro) {
        this.operPro = operPro;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getConproInt() {
        return conproInt;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setConproInt(String conproInt) {
        this.conproInt = conproInt;
    }
}