package com.huake.device.domain.generator;

import javax.annotation.Generated;

public class DiagTree {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String id;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String name;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String des;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String pid;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String nodetype;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String gatetype;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String isleaf;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float precent;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String method;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String points;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float threshold;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getId() {
        return id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setId(String id) {
        this.id = id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getName() {
        return name;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setName(String name) {
        this.name = name;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getDes() {
        return des;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setDes(String des) {
        this.des = des;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getPid() {
        return pid;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setPid(String pid) {
        this.pid = pid;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getNodetype() {
        return nodetype;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setNodetype(String nodetype) {
        this.nodetype = nodetype;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getGatetype() {
        return gatetype;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setGatetype(String gatetype) {
        this.gatetype = gatetype;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getIsleaf() {
        return isleaf;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setIsleaf(String isleaf) {
        this.isleaf = isleaf;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getPrecent() {
        return precent;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setPrecent(Float precent) {
        this.precent = precent;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getMethod() {
        return method;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setMethod(String method) {
        this.method = method;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getPoints() {
        return points;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setPoints(String points) {
        this.points = points;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getThreshold() {
        return threshold;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setThreshold(Float threshold) {
        this.threshold = threshold;
    }
}