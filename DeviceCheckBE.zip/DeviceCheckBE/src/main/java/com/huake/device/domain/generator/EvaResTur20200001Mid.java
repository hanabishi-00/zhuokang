package com.huake.device.domain.generator;

import javax.annotation.Generated;

public class EvaResTur20200001Mid {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer timeOnline;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Byte unit;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer timeOffline;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v1;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v2;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v3;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v4;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v5;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v6;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v7;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v8;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v9;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v10;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v11;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v12;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v13;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v14;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v15;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v16;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v17;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v18;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v19;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v20;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v21;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v22;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v23;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v24;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v25;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float v26;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getTimeOnline() {
        return timeOnline;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setTimeOnline(Integer timeOnline) {
        this.timeOnline = timeOnline;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Byte getUnit() {
        return unit;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setUnit(Byte unit) {
        this.unit = unit;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getTimeOffline() {
        return timeOffline;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setTimeOffline(Integer timeOffline) {
        this.timeOffline = timeOffline;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV1() {
        return v1;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV1(Float v1) {
        this.v1 = v1;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV2() {
        return v2;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV2(Float v2) {
        this.v2 = v2;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV3() {
        return v3;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV3(Float v3) {
        this.v3 = v3;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV4() {
        return v4;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV4(Float v4) {
        this.v4 = v4;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV5() {
        return v5;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV5(Float v5) {
        this.v5 = v5;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV6() {
        return v6;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV6(Float v6) {
        this.v6 = v6;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV7() {
        return v7;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV7(Float v7) {
        this.v7 = v7;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV8() {
        return v8;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV8(Float v8) {
        this.v8 = v8;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV9() {
        return v9;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV9(Float v9) {
        this.v9 = v9;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV10() {
        return v10;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV10(Float v10) {
        this.v10 = v10;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV11() {
        return v11;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV11(Float v11) {
        this.v11 = v11;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV12() {
        return v12;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV12(Float v12) {
        this.v12 = v12;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV13() {
        return v13;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV13(Float v13) {
        this.v13 = v13;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV14() {
        return v14;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV14(Float v14) {
        this.v14 = v14;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV15() {
        return v15;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV15(Float v15) {
        this.v15 = v15;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV16() {
        return v16;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV16(Float v16) {
        this.v16 = v16;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV17() {
        return v17;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV17(Float v17) {
        this.v17 = v17;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV18() {
        return v18;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV18(Float v18) {
        this.v18 = v18;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV19() {
        return v19;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV19(Float v19) {
        this.v19 = v19;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV20() {
        return v20;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV20(Float v20) {
        this.v20 = v20;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV21() {
        return v21;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV21(Float v21) {
        this.v21 = v21;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV22() {
        return v22;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV22(Float v22) {
        this.v22 = v22;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV23() {
        return v23;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV23(Float v23) {
        this.v23 = v23;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV24() {
        return v24;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV24(Float v24) {
        this.v24 = v24;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV25() {
        return v25;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV25(Float v25) {
        this.v25 = v25;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getV26() {
        return v26;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setV26(Float v26) {
        this.v26 = v26;
    }
}