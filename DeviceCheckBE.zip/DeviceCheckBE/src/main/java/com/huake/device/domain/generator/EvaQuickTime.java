package com.huake.device.domain.generator;

import javax.annotation.Generated;

public class EvaQuickTime {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String timeType;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String unitSet;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String timeGap;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer splitIndex;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String timePsg;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getTimeType() {
        return timeType;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setTimeType(String timeType) {
        this.timeType = timeType;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getUnitSet() {
        return unitSet;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setUnitSet(String unitSet) {
        this.unitSet = unitSet;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getTimeGap() {
        return timeGap;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setTimeGap(String timeGap) {
        this.timeGap = timeGap;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getSplitIndex() {
        return splitIndex;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setSplitIndex(Integer splitIndex) {
        this.splitIndex = splitIndex;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getTimePsg() {
        return timePsg;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setTimePsg(String timePsg) {
        this.timePsg = timePsg;
    }
}