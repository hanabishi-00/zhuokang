package com.huake.device.domain.generator;

import javax.annotation.Generated;

public class MadiagSingHis {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer id;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer hisId;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer histtepId;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String hismeasName;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer hisproInt;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getId() {
        return id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setId(Integer id) {
        this.id = id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getHisId() {
        return hisId;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setHisId(Integer hisId) {
        this.hisId = hisId;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getHisttepId() {
        return histtepId;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setHisttepId(Integer histtepId) {
        this.histtepId = histtepId;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getHismeasName() {
        return hismeasName;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setHismeasName(String hismeasName) {
        this.hismeasName = hismeasName;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getHisproInt() {
        return hisproInt;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setHisproInt(Integer hisproInt) {
        this.hisproInt = hisproInt;
    }
}