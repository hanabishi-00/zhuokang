package com.huake.device.domain.generator;

import javax.annotation.Generated;

public class EvaModel {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer time;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String type;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer id;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String name;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer father;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Byte weight;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Boolean state;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String stanDescription;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String points;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getTime() {
        return time;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setTime(Integer time) {
        this.time = time;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getType() {
        return type;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setType(String type) {
        this.type = type;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getId() {
        return id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setId(Integer id) {
        this.id = id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getName() {
        return name;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setName(String name) {
        this.name = name;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getFather() {
        return father;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setFather(Integer father) {
        this.father = father;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Byte getWeight() {
        return weight;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setWeight(Byte weight) {
        this.weight = weight;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Boolean getState() {
        return state;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setState(Boolean state) {
        this.state = state;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getStanDescription() {
        return stanDescription;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setStanDescription(String stanDescription) {
        this.stanDescription = stanDescription;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getPoints() {
        return points;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setPoints(String points) {
        this.points = points;
    }
}