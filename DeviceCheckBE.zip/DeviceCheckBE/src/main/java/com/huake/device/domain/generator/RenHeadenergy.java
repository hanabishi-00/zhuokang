package com.huake.device.domain.generator;

import javax.annotation.Generated;

public class RenHeadenergy {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer unit;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float a;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float b;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getUnit() {
        return unit;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setUnit(Integer unit) {
        this.unit = unit;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getA() {
        return a;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setA(Float a) {
        this.a = a;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getB() {
        return b;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setB(Float b) {
        this.b = b;
    }
}