package com.huake.device.domain.generator;

import javax.annotation.Generated;

public class TreDeterdata101001 {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer time;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Float deter;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getTime() {
        return time;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setTime(Integer time) {
        this.time = time;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Float getDeter() {
        return deter;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setDeter(Float deter) {
        this.deter = deter;
    }
}