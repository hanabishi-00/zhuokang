package com.huake.device.domain.generator;

import javax.annotation.Generated;

public class Classifiedqueryprefix {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer id;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer classifiedid;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String prefix;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getId() {
        return id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setId(Integer id) {
        this.id = id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getClassifiedid() {
        return classifiedid;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setClassifiedid(Integer classifiedid) {
        this.classifiedid = classifiedid;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getPrefix() {
        return prefix;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }
}