package util;

public class resBool{
    private long time;
    private int value;
    private int flag;

    public resBool(long tim, int val, int fla){
        this.time=tim;
        this.value=val;
        this.flag = fla;
    }

        /*public void setTime(long time){
            this.time=time;
        }
        public void setValue(int value){
            this.value=value;
        }
        public  void setFlag(int flag) {
            this.flag = flag;
        }*/

    public long getTime(){
        return time;
    }

    public int getValue(){
        return value;
    }

    public int getFlag(){
        return flag;
    }
}