package util;

public class resFloat{
    private long time;
    private float value;
    private int flag;

    public resFloat(long tim, float val, int fla) {
        time=tim;
        value=val;
        flag=fla;
    }

    public long getTime(){
        return time;
    }

    public float getValue(){
        return value;
    }

    public int getFlag(){
        return flag;
    }
}
