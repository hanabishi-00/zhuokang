package util;

import java.text.ParseException;
import java.util.*;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.github.kevinsawicki.http.HttpRequest;
import element.tree;
import hdb.BoolDataListHolder;
import hdb.FloatDataListHolder;
import hdb.Hdb;
import hdb.InterpolationLine;
import jdk.nashorn.internal.parser.JSONParser;

import javax.swing.*;

public class platformUtil {
    private static final String IP="http://118.178.136.233";
    private static final String PORT="80";
    private static final String USR="A01admin";
    private static final String PSW="123456";

    //诚儿哥写的两个类
    public static class Point {

        private String id;

        private String unit;

        private Long tm;

        private float val;

        private int flag;

        private int dataType;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getUnit() {
            return unit;
        }

        public void setUnit(String unit) {
            this.unit = unit;
        }

        public Long getTm() {
            return tm;
        }

        public void setTm(Long tm) {
            this.tm = tm;
        }

        public float getVal() {
            return val;
        }

        public void setVal(float val) {
            this.val = val;
        }

        public int getFlag() {
            return flag;
        }

        public void setFlag(int flag) {
            this.flag = flag;
        }

        public int getDataType() {
            return dataType;
        }

        public void setDataType(int dataType) {
            this.dataType = dataType;
        }
    }

    public static class Result {
        private List records;

        private int total;

        private int size;

        private  int current;

        private boolean searchCount;

        private int pages;

        public List getRecords() {
            return records;
        }

        public void setRecords(List records) {
            this.records = records;
        }

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public int getSize() {
            return size;
        }

        public void setSize(int size) {
            this.size = size;
        }

        public int getCurrent() {
            return current;
        }

        public void setCurrent(int current) {
            this.current = current;
        }

        public boolean isSearchCount() {
            return searchCount;
        }

        public void setSearchCount(boolean searchCount) {
            this.searchCount = searchCount;
        }

        public int getPages() {
            return pages;
        }

        public void setPages(int pages) {
            this.pages = pages;
        }
    }


    public static void main(String[] args) throws ParseException {
        String token=getToken();
        List<Map> point_id=getID("1号机5号上导轴瓦发电机工况出油边温度Z119", token);
        int[] ids= new int[]{Integer.parseInt((String) point_id.get(0).get("id"))};
        Date[] time_gap=new Date[]{timeUtil.stringToDate("2018/12/19 00:00:00","yyyy/MM/dd HH:mm:ss"),
                timeUtil.stringToDate("2018/12/19 23:59:59","yyyy/MM/dd HH:mm:ss")};
        List<long[]> F_time_psg=getTimepsg_float(time_gap,100,0,new float[]{30,40});
        List<long[]> B_time_psg=getTimepsg_bool(time_gap,826,1);
        List<Point> res=getData_conditon(826, 1, time_gap, 100, 0,0);
        List<resBool> RB=searchBool(time_gap, 826);
        List<resFloat> RF=searchFloat(time_gap,100);
        System.out.println("Finished!");
    }

    public static String getToken(){
        //拼接raw
        Map<String, Object> map = new HashMap();
        map.put("username", USR);
        map.put("password", PSW);
        String jsonString = JSON.toJSONString(map);
//发送请求,取得响应的json数据
        String body = HttpRequest
                .post(IP+":"+PORT+"/ecidi-cmp/sys/login",true)
                .header("Content-Type","application/json")
                .send(jsonString).body();
//将json转换成map
        map = JSON.parseObject(body, Map.class);
//取出token
        map = JSON.parseObject(map.get("result").toString(), Map.class);
        String token = map.get("token").toString();
        System.out.println(token);
        return token;
    }

    public static List<Map> getID(String idName, String token){
        int pageNo=1;
        int pageSize=1;
        //发送get请求获取相应信息,需要将id、pageNo、pageSize替换,token替换为对应token
        HttpRequest request = HttpRequest.get(IP+":"+PORT+"/ecidi-cmp/realtime_data/list",true,
                "name",idName,"pageNo",pageNo,"pageSize",pageSize)
                .header("X-Access-Token", token);
        String body = request.body();
//创建map存放解析的数据对象
        Map<String, Object> map = new HashMap();
        map = JSON.parseObject(body, Map.class);
//从result中解析出record的值
        String result = map.get("result").toString();
        Result results = JSON.parseObject(result, Result.class);
//从record的值中解析出name和id
        List<Map> list = new ArrayList<Map>();
        List records = results.getRecords();
        for(Object o:records) {
            String record = o.toString();
            Map<String, Object> recordMap = new HashMap();
            recordMap = JSON.parseObject(record, Map.class);
//new一个map用于存放结果
            Map<String, String> hashMap = new HashMap<String, String>();
            hashMap.put("name", recordMap.get("name").toString());
            hashMap.put("id", recordMap.get("id").toString());
            hashMap.put("hdbId", recordMap.get("hdbId") == null ? " " :
                    recordMap.get("hdbId").toString());
//将值存放到list中
            list.add(hashMap);
        }
        return list;
    }

    public static List<Point> getData(Date[] time_gap, int[] ids){
        Long startTime=timeUtil.dateToLong(time_gap[0]);
        Long endTime=timeUtil.dateToLong(time_gap[1]);

        String ids_str="";
        for (int i=0;i<ids.length;i++){
            ids_str=ids_str+ids[i];
            if (i!=ids.length-1){
                ids_str=ids_str+",";
            }
        }

        //获取响应数据
        String body = HttpRequest.get(IP+":"+PORT+"/ecidi-cmp/his_data/query", true,
                "ids", ids_str, "starttime", startTime,"endtime",endTime).body();
        //创建实体类用于存放结果
        JSONObject JO = JSONObject.parseObject(body);
        JSONArray JA = JO.getJSONArray("result");
        //将JA中的测点历史数据存放到list中
        List<Point> pointList = new ArrayList<>();
        if (JA!=null) {
            for (int i = 0; i < JA.size(); i++) {
                JSONObject JO_i = (JSONObject) JA.get(i);
                long tm = JO_i.getLong("tm");
                float value = JO_i.getFloat("value");
                int flag = JO_i.getInteger("flag");
                Point p_i = new Point();
                p_i.setTm(tm);
                p_i.setVal(value);
                p_i.setFlag(flag);
                pointList.add(p_i);
            }
        }

        return pointList;
    }

    public static List<Point> getData(Date[] time_gap, int id, int point_type, int interval){
        Long startTime=timeUtil.dateToLong(time_gap[0]);
        Long endTime=timeUtil.dateToLong(time_gap[1]);

        String ids_str=id+"";

        //获取响应数据
        String body = HttpRequest.get(IP+":"+PORT+"/ecidi-cmp/his_data/query1", true,
                "id", ids_str, "starttime", startTime,"endtime",endTime,
                "datatype", point_type, "interval", interval).body();
        //创建实体类用于存放结果
        JSONObject JO = JSONObject.parseObject(body);
        JSONArray JA = JO.getJSONArray("result");
        //将JA中的测点历史数据存放到list中
        List<Point> pointList = new ArrayList<>();
        if (JA!=null) {
            for (int i = 0; i < JA.size(); i++) {
                JSONObject JO_i = (JSONObject) JA.get(i);
                long tm = JO_i.getLong("tm");
                float value = JO_i.getFloat("value");
                int flag = JO_i.getInteger("flag");
                Point p_i = new Point();
                p_i.setTm(tm);
                p_i.setVal(value);
                p_i.setFlag(flag);
                pointList.add(p_i);
            }
        }

        return pointList;
    }

    public static List<Point> getData_conditon(int con_id, int con_mark,
                                               Date[] time_gap, int id,  int point_type, int interval){
        Long startTime=timeUtil.dateToLong(time_gap[0]);
        Long endTime=timeUtil.dateToLong(time_gap[1]);

        String id1_str=con_id+"";
        String id2_str=id+"";

        //获取响应数据
        String body = HttpRequest.get(IP+":"+PORT+"/ecidi-cmp/his_data/query3", true,
                "id1", id1_str, "datalag", con_mark,
                "starttime", startTime,"endtime",endTime, "id2", id2_str,
                "datatype", point_type, "interval", interval).body();
        //创建实体类用于存放结果
        JSONObject JO = JSONObject.parseObject(body);
        JSONArray JA = JO.getJSONArray("result");
        //将JA中的测点历史数据存放到list中
        List<Point> pointList = new ArrayList<>();
        if (JA!=null) {
            for (int i = 0; i < JA.size(); i++) {
                JSONObject JO_i = (JSONObject) JA.get(i);
                long tm = JO_i.getLong("tm");
                float value = JO_i.getFloat("value");
                int flag = JO_i.getInteger("flag");
                Point p_i = new Point();
                p_i.setTm(tm);
                p_i.setVal(value);
                p_i.setFlag(flag);
                pointList.add(p_i);
            }
        }

        return pointList;
    }

    public static List<long[]> getTimepsg_float(Date[] time_gap, int id, int mode, float[] th){
        Long startTime=timeUtil.dateToLong(time_gap[0]);
        Long endTime=timeUtil.dateToLong(time_gap[1]);

        String id_str=id+"";

        //获取响应数据
        String body = "";
        HttpRequest HR = null;
        if (mode==0) {
            HR=HttpRequest.get(IP + ":" + PORT + "/ecidi-cmp/his_data/query2", true,
                    "id", id_str, "datatype", 0,
                    "starttime", startTime, "endtime", endTime,
                    "sub-thrshold", th[0]+"", "up-threshold", th[1]+"");
        }
        else if (mode==-1){
            HR= HttpRequest.get(IP + ":" + PORT + "/ecidi-cmp/his_data/query2", true,
                    "id", id_str, "datatype", 0,
                    "starttime", startTime, "endtime", endTime,
                    "sub-thrshold", th[0]+"");
        }
        else if (mode==1){
            HR = HttpRequest.get(IP + ":" + PORT + "/ecidi-cmp/his_data/query2", true,
                    "id", id_str, "datatype", 0,
                    "starttime", startTime, "endtime", endTime,
                    "up-threshold", th[0]+"");
        }
        body =HR.body();

        //创建实体类用于存放结果
        JSONObject JO = JSONObject.parseObject(body);
        JSONArray JA = JO.getJSONArray("result");
        //将JA中的测点历史数据存放到list中
        List<long[]> pointList = new ArrayList<>();
        if (JA!=null) {
            for (int i = 0; i < JA.size(); i++) {
                JSONObject JO_i = (JSONObject) JA.get(i);
                long st_tm = JO_i.getLong("starttime");
                long ed_tm = JO_i.getLong("endtime");
                pointList.add(new long[]{st_tm,ed_tm});
            }
        }

        return pointList;
    }

    public static List<long[]> getTimepsg_bool(Date[] time_gap, int id, int tag){
        Long startTime=timeUtil.dateToLong(time_gap[0]);
        Long endTime=timeUtil.dateToLong(time_gap[1]);

        String id_str=id+"";

        //获取响应数据
        String body = HttpRequest.get(IP + ":" + PORT + "/ecidi-cmp/his_data/query2", true,
                    "id", id_str, "datatype", 1,
                    "starttime", startTime, "endtime", endTime,
                    "datalag", tag).body();

        //创建实体类用于存放结果
        JSONObject JO = JSONObject.parseObject(body);
        JSONArray JA = JO.getJSONArray("result");
        //将JA中的测点历史数据存放到list中
        List<long[]> pointList = new ArrayList<>();
        if (JA!=null) {
            for (int i = 0; i < JA.size(); i++) {
                JSONObject JO_i = (JSONObject) JA.get(i);
                long st_tm = JO_i.getLong("starttime");
                long ed_tm = JO_i.getLong("endtime");
                pointList.add(new long[]{st_tm,ed_tm});
            }
        }

        return pointList;
    }


    // 机组状态测点号
    static final int[] pump_state_point_id=new int[]{826, 2740, 4654, 6568};//各机组抽水态id
    static final int[] tur_state_point_id=new int[]{822, 2736, 4650, 6564};//各机组发电态id
    static final int[] terminal_point_id=new int[]{819, 2733, 4647, 6561};//各机组停机态id

    /*public static void main(String[] args) throws ParseException {
        *//*long[] time_long={1537397423,1538335000};
        Date d1=timeUtil.longToDate(time_long[0]*1000,"yyyy-MM-dd HH:mm:ss");
        Date d2=timeUtil.longToDate(time_long[1]*1000,"yyyy-MM-dd HH:mm:ss");*//*

        Date d1=timeUtil.stringToDate("2017-12-29 00:00:00","yyyy-MM-dd HH:mm:ss");
        Date d2=timeUtil.stringToDate("2017-12-29 23:59:59","yyyy-MM-dd HH:mm:ss");

        Date[] time_d={d1,d2};
        Date[][] steady_turbine=steadyTime(time_d,1, tree.work_condition_turbine);
        Date[][] steady_pump=steadyTime(time_d,1, tree.work_condition_pump);
        //List<resBool> rb=searchBool(time_d,822);
        List<resFloat> rf=searchFloat(time_d,50);
        for (int f_i=0;f_i<rf.size();f_i++) {
            System.out.println("record "+f_i+": " + rf.get(f_i).getTime() + " " + rf.get(f_i).getValue() + " " + rf.get(f_i).getFlag());
        }

    }*/

    public static List searchFloat(Date[] time_gap, int id){//查询数据库中单精量
        List<resFloat> resList=new ArrayList<>();

        //查询
        List<Point> dataList=getData(time_gap, id, 0, 0);

        //写入
        for(int i=0; i< dataList.size(); i++){
            long tm  = dataList.get(i).getTm();
            float value = dataList.get(i).getVal();
            int flag = dataList.get(i).getFlag();
            resFloat rf=new resFloat(tm,value,flag);
            resList.add(rf);

            /*//输出
            System.out.print("单精量测点: " + id);
            System.out.print(", 时间: " + tm);
            System.out.print(", 测点值: " + value);
            System.out.print(", 标志: " + flag);
            System.out.print("\n");*/
        }

//        System.out.println("Goodbye!");
        return resList;
    }

    public static List searchBool(Date[] time_gap, int id) throws ParseException {//查询数据库中状态量
        List<resBool> resList=new ArrayList<>();
        long t1=timeUtil.dateToLong(time_gap[0])/1000;
        long t2=timeUtil.dateToLong(time_gap[1])/1000;

        //连接数据库并查询
        List<Point> dataList=getData(time_gap, id, 1, -1);

        //对查询结果进行处理（原函数仅查询原值，须对查询时段首末时刻进行插值）
        int origin_data_len=dataList.size();//原时段查询得到的原值数
        if (  origin_data_len > 0 ){//如果有查询结果
            if (dataList.get(0).getTm()<t1){//如果首实测值时刻小于开始查询时间，向前查询一天
                List<resBool> dataList_sub = searchBoolForward(time_gap, id);
                int first_value=dataList_sub.size();
                long tm_sub  = t1;
                int value_sub = dataList_sub.get(first_value-1).getValue();//取查询到的最接近查询起始时刻的值
                int flag_sub = 3;

                resBool rf = new resBool(tm_sub, value_sub, flag_sub);
                resList.add(rf);
            }

            //存储历史数据
            for(int i=0; i< dataList.size(); i++){
                long tm  = dataList.get(i).getTm();
                float value = dataList.get(i).getVal();
                int flag = dataList.get(i).getFlag();
                if ((i==0)||(i==dataList.size()-1)||(flag!=3)) {//如果是首末时刻值或首末时刻间原值，则存储
                    resBool rf = new resBool(tm, (int) value, flag);
                    resList.add(rf);

                /*//输出
                System.out.print("状态量测点: " + id);
                System.out.print(", 时间: " + tm);
                System.out.print(", 测点值: " + value);
                System.out.print(", 标志: " + flag);
                System.out.print("\n");*/
                }
            }

            //添加查询末时刻数据
            if (dataList.get(origin_data_len-1).getTm()<t2){//若时段内查询到的最末原值对应时刻在查询结束时刻前
                long tm_sub  = t2;
                float value_sub = dataList.get(origin_data_len-1).getVal();//取最末原值
                int flag_sub = 3;

                resBool rf = new resBool(tm_sub, (int) value_sub, flag_sub);
                resList.add(rf);
            }
        }
        else{//无原值可被查询
            List<resBool> dataList_sub = searchBoolForward(time_gap, id);
            int first_value=dataList_sub.size();
            int value_sub = dataList_sub.get(first_value-1).getValue();//取查询到的最接近查询起始时刻的值
            int flag_sub = 3;

            //存入首末时刻值
            resBool rf_1 = new resBool(t1, value_sub, flag_sub);
            resBool rf_2 = new resBool(t2, value_sub, flag_sub);
            resList.add(rf_1);
            resList.add(rf_2);
        }

        resList=cut_redundency(resList);//去除重复值

//        System.out.println("Goodbye!");
        return resList;
    }

    public static List<resBool> searchBoolForward(Date[] time_gap, int id) throws ParseException {//从当前时间开始按天向前搜索直至查询得到结果
        List<resBool> res=new ArrayList<>();
        Calendar[] c=new Calendar[2];
        c[0]=Calendar.getInstance();
        c[0].setTime(time_gap[0]);
        c[0].add(Calendar.DAY_OF_YEAR, -1);
        c[1]=Calendar.getInstance();
        c[1].setTime(time_gap[0]);
        c[1].add(Calendar.SECOND, -1);
        Date[] new_time_gap=new Date[]{c[0].getTime(),c[1].getTime()};

        List<Point> dataList=getData(new_time_gap, id, 1, -1);

        if (dataList.size()>0) {//有真实值记录
            for (int i = 0; i < dataList.size(); i++) {
                long tm = dataList.get(i).getTm();
                float val = dataList.get(i).getVal();
                int flag = dataList.get(i).getFlag();

                res.add(new resBool(tm, (int) val, flag));
            }
        }
        else {//向前推一天后查询
            res =searchBoolForward( new_time_gap, id);
        }

        return res;
    }

    public static Date[][] steadyTimeSimple(Date[] time_gap, int id, int steadyThreshold, int end_th) throws ParseException {//查询发电态、抽水态的稳态时段（设置达到稳态的时间为开机后steadyThreshold秒）
        //作为steadyTime的子函数使用
        int close_threshold=end_th;//关机前120s为稳态结束时刻
        Date[][] passage = null;//每行存储一对符合要求的稳态工况起始时段
        long gap=(timeUtil.dateToLong(time_gap[1])-timeUtil.dateToLong(time_gap[0]))/1000;
        if (gap>steadyThreshold) {//如果查询时间>threshold
            List<resBool> origin_data = searchBool(time_gap, id);//存储time_gap内的id测点值
            int total_len = origin_data.size();

            for (int i = 0; i < total_len; i++) {
                long[] per_passage_long = new long[2];
                long[] neighbor_time_gap = new long[2];//相邻两跳变时刻（为1的时段）

                for (int j1 = i; j1 < total_len - 1; j1++) {
                    if ((j1 == 0) && (origin_data.get(j1).getValue() == 1)) {//如果首位为1
                        neighbor_time_gap[0] = origin_data.get(j1).getTime();//直接存储
                        i = j1;
                        break;
                    } else if ((origin_data.get(j1).getValue() == 0) &&
                            (origin_data.get(j1 + 1).getValue() == 1)) {//上升沿
                        neighbor_time_gap[0] = origin_data.get(j1 + 1).getTime();//前一时刻
                        i = j1 + 1;
                        break;
                    }
                }

                for (int j2 = i; j2 < total_len; j2++) {
                    if (j2 < total_len - 1) {//未到最后一位
                        if ((origin_data.get(j2).getValue() == 1) &&
                                (origin_data.get(j2 + 1).getValue() == 0)) {//下降沿
                            neighbor_time_gap[1] = origin_data.get(j2 + 1).getTime();//后一时刻
                            i = j2 ;
                            break;
                        }
                    } else if (origin_data.get(j2).getValue() == 1) {//到最后一位且为1，直接存储
                        neighbor_time_gap[1] = origin_data.get(j2).getTime();//后一时刻
                    }
                }

                if (neighbor_time_gap != null) {
                    if ((neighbor_time_gap[1] - neighbor_time_gap[0]) > steadyThreshold+close_threshold) {
                        //如果前一上升沿时间与后一个下降沿时间差大于达稳态时间阈值
                        per_passage_long[0] = neighbor_time_gap[0] + steadyThreshold;
                        per_passage_long[1] = neighbor_time_gap[1]-close_threshold;

                        Date[] per_passage = new Date[2];
                        per_passage[0] = timeUtil.longToDate(per_passage_long[0] * 1000, "yyyy-MM-dd HH:mm:ss");
                        per_passage[1] = timeUtil.longToDate(per_passage_long[1] * 1000, "yyyy-MM-dd HH:mm:ss");

                        if (passage == null) {
                            passage = new Date[1][2];
                            passage[0] = per_passage;
                        } else {
                            Date[][] temp_passage = new Date[passage.length + 1][2];
                            System.arraycopy(passage, 0, temp_passage, 0, passage.length);
                            temp_passage[passage.length] = per_passage;
                            passage = temp_passage;
                        }
                    }
                }
            }
        }

        return passage;
    }

    public static Date[][] steadyTimeSimple(Date[] time_gap, int id, int steadyThreshold) throws ParseException {//查询发电态、抽水态的稳态时段（设置达到稳态的时间为开机后steadyThreshold秒）
        //作为steadyTime的子函数使用
        int close_threshold=120;//关机前120s为稳态结束时刻
        Date[][] passage = null;//每行存储一对符合要求的稳态工况起始时段
        long gap=(timeUtil.dateToLong(time_gap[1])-timeUtil.dateToLong(time_gap[0]))/1000;
        if (gap>steadyThreshold) {//如果查询时间>threshold
            List<resBool> origin_data = searchBool(time_gap, id);//存储time_gap内的id测点值
            int total_len = origin_data.size();

            for (int i = 0; i < total_len; i++) {
                long[] per_passage_long = new long[2];
                long[] neighbor_time_gap = new long[2];//相邻两跳变时刻（为1的时段）

                for (int j1 = i; j1 < total_len - 1; j1++) {
                    if ((j1 == 0) && (origin_data.get(j1).getValue() == 1)) {//如果首位为1
                        neighbor_time_gap[0] = origin_data.get(j1).getTime();//直接存储
                        i = j1;
                        break;
                    } else if ((origin_data.get(j1).getValue() == 0) &&
                            (origin_data.get(j1 + 1).getValue() == 1)) {//上升沿
                        neighbor_time_gap[0] = origin_data.get(j1 + 1).getTime();//前一时刻
                        i = j1 + 1;
                        break;
                    }
                }

                for (int j2 = i; j2 < total_len; j2++) {
                    if (j2 < total_len - 1) {//未到最后一位
                        if ((origin_data.get(j2).getValue() == 1) &&
                                (origin_data.get(j2 + 1).getValue() == 0)) {//下降沿
                            neighbor_time_gap[1] = origin_data.get(j2 + 1).getTime();//后一时刻
                            i = j2 ;
                            break;
                        }
                    } else if (origin_data.get(j2).getValue() == 1) {//到最后一位且为1，直接存储
                        neighbor_time_gap[1] = origin_data.get(j2).getTime();//后一时刻
                    }
                }

                if (neighbor_time_gap != null) {
                    if ((neighbor_time_gap[1] - neighbor_time_gap[0]) > steadyThreshold+close_threshold) {
                        //如果前一上升沿时间与后一个下降沿时间差大于达稳态时间阈值
                        per_passage_long[0] = neighbor_time_gap[0] + steadyThreshold;
                        per_passage_long[1] = neighbor_time_gap[1]-close_threshold;

                        Date[] per_passage = new Date[2];
                        per_passage[0] = timeUtil.longToDate(per_passage_long[0] * 1000, "yyyy-MM-dd HH:mm:ss");
                        per_passage[1] = timeUtil.longToDate(per_passage_long[1] * 1000, "yyyy-MM-dd HH:mm:ss");

                        if (passage == null) {
                            passage = new Date[1][2];
                            passage[0] = per_passage;
                        } else {
                            Date[][] temp_passage = new Date[passage.length + 1][2];
                            System.arraycopy(passage, 0, temp_passage, 0, passage.length);
                            temp_passage[passage.length] = per_passage;
                            passage = temp_passage;
                        }
                    }
                }
            }
        }

        return passage;
    }

    //计算在某时间间隔内某号机组的稳态工作时段
    public static Date[][] steadyTime(Date[] time_gap, int unit_id, int type, int steadyThreshold) throws ParseException {
        Date[][] res_time_psg = new Date[0][];
        int[] state_point_id;
        //首先定义各机组的状态测点
        switch (type){//判断查询状态
            case tree.work_condition_pump://抽水工况
                state_point_id=pump_state_point_id;//各机组抽水态id
                int unit_choushui_id=state_point_id[unit_id-1];
                res_time_psg=steadyTimeSimple(time_gap, unit_choushui_id,steadyThreshold);
                break;
            default://非-1表示正功率，发电，受其他机组启停的影响
                state_point_id=tur_state_point_id;//各机组发电态id
                int unit_fadian_id=state_point_id[unit_id-1];
                Date[][] current_unit_time_psg=steadyTimeSimple(time_gap, unit_fadian_id,steadyThreshold);//查询当前机组的启停状态
                if (current_unit_time_psg==null){
                    return null;
                }

                //查询所有其它机组在该时段内的开关机状态
                List<List> all_other_unit_state=new ArrayList<>();
                for (int i=0;i<state_point_id.length;i++){
                    if (i!=unit_id-1){
                        List<resBool> single_unit_state = searchBool(time_gap, state_point_id[i]);
                        all_other_unit_state.add(cut_redundency(single_unit_state));
                    }
                }

                List<long[]> CUTP_long_list=new ArrayList<>();//存入所选机组稳态时段秒值的List
                for (int k=0;k<current_unit_time_psg.length;k++){
                    long[] current_unit_time_psg_row=new long[2];
                    current_unit_time_psg_row[0]=timeUtil.dateToLong(current_unit_time_psg[k][0])/1000;
                    current_unit_time_psg_row[1]=timeUtil.dateToLong(current_unit_time_psg[k][1])/1000;
                    CUTP_long_list.add(current_unit_time_psg_row);
                }

                for (int j=0;j<all_other_unit_state.size();j++){//对其他机组操作时刻和选定机组稳态时段进行遍历比较
                    List<resBool> other_unit_state_per=all_other_unit_state.get(j);

                    if (other_unit_state_per==null){
                        continue;
                    }

                    for (int jj=0;jj<other_unit_state_per.size();jj++){
                        resBool other_unit_state_jj=other_unit_state_per.get(jj);
                        for (int jjj=0;jjj<CUTP_long_list.size();jjj++){//对时间点在选定机组稳态时段中进行遍历判断修改
                            long st_time=CUTP_long_list.get(jjj)[0];
                            long end_time=CUTP_long_list.get(jjj)[1];

                            //第一种情况，其他机组开关机时间落在稳态时段外，但距离稳态开始时间小于稳态时间阈值
                            if ((other_unit_state_jj.getTime()<st_time)&&
                                    (other_unit_state_jj.getTime()+steadyThreshold>st_time)&&
                                    (other_unit_state_jj.getFlag()==2)){
                                if(end_time-other_unit_state_jj.getTime()-steadyThreshold<=0){//如果其他机组达到稳态后的时间在当前机组稳态结束时间后
                                    CUTP_long_list.remove(jjj);//删除jjj条的记录
                                }
                                else {//其他机组达到稳态后的时间在当前机组稳态结束时间前，则缩短稳态时间，后延稳态开始时间
                                    CUTP_long_list.set(jjj, new long[]{other_unit_state_jj.getTime() + steadyThreshold, end_time});//延后稳态开始时间修改记录
                                }
                                break;
                            }
                            //第二种情况，其他机组开关机时间点落在稳态时段内
                            if ((other_unit_state_jj.getTime()>st_time)&&
                                    (other_unit_state_jj.getTime()<end_time)&&
                                    (other_unit_state_jj.getFlag()==2)){//其他机组有为原值且在选定机组单机稳定时段内的开关机记录
                                CUTP_long_list.set(jjj,new long[]{st_time,other_unit_state_jj.getTime()});//修改记录
                                if (end_time-other_unit_state_jj.getTime()>steadyThreshold){//如果发生时间在结束时间阈值秒数之前，新增记录
                                    CUTP_long_list.add(jjj+1,new long[] {other_unit_state_jj.getTime()+steadyThreshold,end_time});
                                }
                                break;
                            }
                        }
                    }
                }

                int time_psg_num=CUTP_long_list.size();//总的稳态时间片段数
                res_time_psg=new Date[time_psg_num][2];
                for (int rr=0;rr<time_psg_num;rr++){
                    Date d1=timeUtil.longToDate(CUTP_long_list.get(rr)[0]*1000, "yyyy-MM-dd HH:mm:ss");
                    Date d2=timeUtil.longToDate(CUTP_long_list.get(rr)[1]*1000, "yyyy-MM-dd HH:mm:ss");
                    res_time_psg[rr]= new Date[]{d1, d2};
                }
        }
        return res_time_psg;
    }

    public static Date[][] steadyTime(Date[] time_gap, int unit_id, int type) throws ParseException {//设置默认阈值为20min（1200s）

        int steadyThreshold=1200;
        Date[][] res=steadyTime( time_gap,  unit_id,  type, steadyThreshold);
        return res;
    }

    public static Date[][] workTime(Date[] time_gap, int unit_id, int work_type ) throws ParseException {
        Date[][] res;
        List<Date[]> time_psg=new ArrayList<>();
        int[] mark = {1, 0};//默认为统计1到0的时段
        int[] state_point_id=tur_state_point_id;//根据工况类型设置状态测点id
        if (work_type==tree.work_condition_pump){
            state_point_id=pump_state_point_id;
        }

        //统计对应工况时段
        List<resBool> ori_data_pump=searchBool(time_gap, state_point_id[unit_id-1]);
        ori_data_pump=cut_redundency(ori_data_pump);
        for (int ii = 1; ii < ori_data_pump.size()-1; ii++) {
            if (ori_data_pump.get(ii).getValue()==mark[0]&&ori_data_pump.get(ii+1).getValue()==mark[1]){
                Date t_ii_mk0=timeUtil.longToDate(ori_data_pump.get(ii).getTime()*1000,
                        "yyyy-MM-dd HH:mm:ss");
                Date t_ii_mk1=timeUtil.longToDate(ori_data_pump.get(ii+1).getTime()*1000,
                        "yyyy-MM-dd HH:mm:ss");
                time_psg.add(new Date[]{t_ii_mk0,t_ii_mk1});
            }
        }
        if (ori_data_pump.get(ori_data_pump.size()-2).getValue()==mark[0]&&
                ori_data_pump.get(ori_data_pump.size()-1).getValue()==mark[0]){
            Date t_ii_mk0=timeUtil.longToDate(ori_data_pump.get(ori_data_pump.size()-2).getTime()*1000,
                    "yyyy-MM-dd HH:mm:ss");
            Date t_ii_mk1=timeUtil.longToDate(ori_data_pump.get(ori_data_pump.size()-1).getTime()*1000,
                    "yyyy-MM-dd HH:mm:ss");
            time_psg.add(new Date[]{t_ii_mk0,t_ii_mk1});
        }

        res=new Date[time_psg.size()][];
        for (int i=0;i<res.length;i++){//组织输出
            res[i]=time_psg.get(i);
        }

        return res;
    }

    public static Date[][] terminalTime(Date[] time_gap, int unit_id, int type) throws ParseException {
        Date[][] res;
        List<long[]> time_psg=new ArrayList<>();
        int[] mark = {1, 0};//默认为统计1到0的时段
        int[] state_point_id=terminal_point_id;//设置状态测点id

        //统计对应工况时段
        List<resBool> ori_data_pump=searchBool(time_gap, state_point_id[unit_id-1]);
        ori_data_pump=cut_redundency(ori_data_pump);
        for (int ii = 1; ii < ori_data_pump.size()-1; ii++) {
            if (ori_data_pump.get(ii).getValue()==mark[0]&&ori_data_pump.get(ii+1).getValue()==mark[1]){
                time_psg.add(new long[]{ori_data_pump.get(ii).getTime(),ori_data_pump.get(ii+1).getTime()});
            }
        }
        if (ori_data_pump.get(ori_data_pump.size()-2).getValue()==mark[0]&&
                ori_data_pump.get(ori_data_pump.size()-1).getValue()==mark[0]){
            time_psg.add(new long[]{ori_data_pump.get(ori_data_pump.size()-2).getTime(),ori_data_pump.get(ori_data_pump.size()-1).getTime()});
        }

        //若为停机稳态，则需进行时段筛选
        if (type>0) {
            List<long[]> temp_time_psg = new ArrayList<>();
            for (int i = 0; i < time_psg.size(); i++) {
                long t1 = time_psg.get(i)[0] + 3600;
                long t2 = time_psg.get(i)[1] - 120;
                if (t1 < t2) {
                    temp_time_psg.add(new long[]{t1, t2});
                }
            }
            time_psg=temp_time_psg;
        }

        //整理结果
        res=new Date[time_psg.size()][];
        for (int i=0;i<res.length;i++){//组织输出
            Date t1=timeUtil.longToDate(time_psg.get(i)[0]*1000,
                    "yyyy-MM-dd HH:mm:ss");
            Date t2=timeUtil.longToDate(time_psg.get(i)[1]*1000,
                    "yyyy-MM-dd HH:mm:ss");
            res[i]=new Date[]{t1,t2};
        }

        return res;
    }

    public static List<resBool> cut_redundency(List<resBool> src_list){//删除src_list中的连续重复元素（保留两端值）
        //该函数会保留最后时刻的记录，以保证末时刻的记录存在
        List<resBool> res=src_list;
        int ii=0;//删除的元素数量
        if (src_list.size()>2) {
            for (int i = 0; i < src_list.size() - 2; i++) {
                if (src_list.get(i).getValue() == src_list.get(i + 1).getValue()) {//如果出现了重复元素
                    res.remove(i + 1 - ii);
                    ii++;
                }
            }
        }
        return res;
    }

    public static float mean(int[] number){//计算均值
        float res;
        int count=0;
        int len=number.length;
        for (int i=0;i<len;i++){
            count=count+number[i];
        }
        res=count/len;
        return res;
    }

    public static float mean(float[] number) {
        float res = 0;
        float count = 0;
        if (number != null) {
            int len = number.length;
            for (int i = 0; i < len; i++) {
                count = count + number[i];
            }
            res = count / len;
        }
        return res;
    }


    public static float maxx(float[] number){
        float res=number[0];
        int len=number.length;
        if (len>1) {
            for (int i = 0; i < len - 1; i++) {
                res=Math.max(res,number[i+1]);
            }
        }
        return res;
    }

    public static float minn(float[] number){
        float res=number[0];
        int len=number.length;
        if (len>1) {
            for (int i = 0; i < len - 1; i++) {
                res=Math.min(res,number[i+1]);
            }
        }
        return res;
    }
}
